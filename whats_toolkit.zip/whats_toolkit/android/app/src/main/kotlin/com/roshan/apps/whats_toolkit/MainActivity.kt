package com.roshan.apps.whats_toolkit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
