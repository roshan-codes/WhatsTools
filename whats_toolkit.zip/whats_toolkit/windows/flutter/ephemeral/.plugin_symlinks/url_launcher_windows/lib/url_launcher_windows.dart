// The url_launcher_platform_interface defaults to MethodChannelUrlLauncher
// as its instance, which is all the Windows implementation needs. This file
// is here to silence warnings when publishing to pub.
