## 0.0.1+3

* Update Dart SDK constraint in example.

## 0.0.1+2

* Check in windows/ directory for example/

## 0.0.1+1

* Update README to reflect endorsement.

## 0.0.1

* Initial Windows implementation of `url_launcher`.
