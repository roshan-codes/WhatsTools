// import 'package:flutter/material.dart';
// import 'package:whats_toolkit/status/video_status.dart';
//
// import 'image_status.dart';
//
// class StatusTab extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return DefaultTabController(
//       length: 2,
//       child: Scaffold(
//           appBar: AppBar(
//             backgroundColor:  Color(0xff128C7E),
//             bottom: TabBar(
//               indicatorColor: Colors.greenAccent,
//               onTap: (index) {
//                 // Tab index when user select it, it start from zero
//               },
//               tabs: [
//                 Tab(child: Text("Images"),),
//                 Tab(child: Text("Videos"),),
//               ],
//             ),
//             title: Text('Whatsapp Status'),
//           ),
//           body: TabBarView(
//             children: [
//               ImageStatus(),
//               VideoListView(),
//             ],
//           ),
//         ),
//     );
//   }
// }
